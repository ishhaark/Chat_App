const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const jwt = require('jsonwebtoken');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);

// ----------------------
// CORS and Middleware
// ----------------------
app.use(cors({
   origin: ['http://10.10.15.140', 'http://localhost'],
    credentials: false,
    allowedHeaders: ['Content-Type', 'Authorization'], // Add Authorization here
    exposedHeaders: ['Authorization']
}));

app.use(express.json());
app.use(cookieParser());

// ----------------------
// WebSocket (Socket.io)
// ----------------------
const io = new Server(server, {
    cors: {
        origin: ["http://localhost", "http://10.10.15.140"],
        credentials: true
    }
});

// Store online users
const onlineUsers = new Map();

// ----------------------
// MongoDB Connection
// ----------------------
mongoose.connect(
    "mongodb+srv://ik459123_db_user:vILJAuoNl2zW7UGb@cluster0.hlbadfq.mongodb.net/chat"
)
.then(() => console.log("MongoDB Connected"))
.catch(err => console.log("MongoDB Error:", err));

// ----------------------
// Schemas
// ----------------------
const UserSchema = new mongoose.Schema({
    first_name: String,
    last_name: String,
    email: { type: String, unique: true },
    mobile: String,
    username: String,
    password: String,
    is_online: { type: Boolean, default: false },
    last_seen: { type: Date, default: Date.now }
});

const User = mongoose.model("user", UserSchema);

const MessageSchema = new mongoose.Schema({
    sender: { type: mongoose.Schema.Types.ObjectId, ref: 'user' },
    receiver: { type: mongoose.Schema.Types.ObjectId, ref: 'user' },
    message: String,
    is_read: { type: Boolean, default: false },
    created_at: { type: Date, default: Date.now }
});

const Message = mongoose.model("message", MessageSchema);

// ----------------------
// JWT Configuration
// ----------------------
const JWT_SECRET = "your_secret_key_here_change_this";

// ----------------------
// Auth Middleware
// ----------------------
const auth = async (req, res, next) => {
    const token = req.cookies.token;

    if (!token) {
        return res.status(401).json({ 
            status: "error", 
            message: "Authentication required" 
        });
    }

    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        req.user = decoded;
        next();
    } catch (err) {
        return res.status(401).json({ 
            status: "error", 
            message: "Invalid token" 
        });
    }
};

// ----------------------
// Socket.io Connection
// ----------------------
io.on('connection', (socket) => {
    console.log('User connected:', socket.id);

    // Join user to their room
    socket.on('join', (userId) => {
        socket.join(userId);
        onlineUsers.set(userId, socket.id);
        
        // Update user online status
        User.findByIdAndUpdate(userId, { 
            is_online: true, 
            last_seen: new Date() 
        }).exec();

        // Notify other users
        socket.broadcast.emit('user-online', userId);
    });

    // Send message
    socket.on('send-message', async (data) => {
        try {
            const { sender, receiver, message } = data;
            
            // Save message to database
            const newMessage = new Message({
                sender,
                receiver,
                message
            });
            
            await newMessage.save();
            
            // Populate sender details
            const populatedMessage = await Message.findById(newMessage._id)
                .populate('sender', 'username')
                .populate('receiver', 'username');
            
            // Emit to receiver
            io.to(receiver).emit('receive-message', populatedMessage);
            
            // Emit back to sender for confirmation
            io.to(sender).emit('message-sent', populatedMessage);
        } catch (error) {
            console.error('Error sending message:', error);
        }
    });

    // Typing indicator
    socket.on('typing', (data) => {
        socket.to(data.receiver).emit('typing', {
            sender: data.sender,
            isTyping: data.isTyping
        });
    });

    // User disconnected
    socket.on('disconnect', () => {
        // Find user by socket ID
        let userId = null;
        for (const [key, value] of onlineUsers.entries()) {
            if (value === socket.id) {
                userId = key;
                break;
            }
        }
        
        if (userId) {
            onlineUsers.delete(userId);
            
            // Update user offline status
            User.findByIdAndUpdate(userId, { 
                is_online: false,
                last_seen: new Date()
            }).exec();
            
            // Notify other users
            socket.broadcast.emit('user-offline', userId);
        }
        
        console.log('User disconnected:', socket.id);
    });
});

// ----------------------
// API Routes
// ----------------------

// 1. Get current user
app.get('/api/me', auth, async (req, res) => {
    try {
        const user = await User.findById(req.user.id).select("-password");
        if (!user) {
            return res.status(404).json({ 
                status: "error", 
                message: "User not found" 
            });
        }
        res.json({ 
            status: "success", 
            user 
        });
    } catch (err) {
        console.error('Error in /api/me:', err);
        res.status(500).json({ 
            status: "error", 
            message: "Server error" 
        });
    }
});

// 2. Register
app.post('/api/register', async (req, res) => {
    try {
        const existingUser = await User.findOne({ 
            $or: [
                { email: req.body.email },
                { username: req.body.username }
            ] 
        });

        if (existingUser) {
            return res.status(400).json({ 
                status: "error", 
                message: "Email or username already exists" 
            });
        }

        const user = new User(req.body);
        await user.save();
        
        res.json({ 
            status: "success", 
            message: "Registration successful" 
        });
    } catch (err) {
        console.error('Registration error:', err);
        res.status(500).json({ 
            status: "error", 
            message: "Registration failed" 
        });
    }
});

// 3. Login
app.post('/api/login', async (req, res) => {
    try {
        const { identifier, password } = req.body;

        const user = await User.findOne({
            $or: [
                { email: identifier }, 
                { username: identifier }
            ]
        });

        if (!user || user.password !== password) {
            return res.status(401).json({ 
                status: "error", 
                message: "Invalid credentials" 
            });
        }

        const payload = { 
            id: user._id, 
            username: user.username, 
            email: user.email 
        };
        
        const token = jwt.sign(payload, JWT_SECRET, { expiresIn: "24h" });

        res.cookie("token", token, {
            httpOnly: true,
            secure: false,
            maxAge: 24 * 60 * 60 * 1000
        });

        res.json({
            status: "success",
            token,
            user: {
                _id: user._id,
                email: user.email,
                username: user.username,
                first_name: user.first_name,
                last_name: user.last_name
            }
        });
    } catch (err) {
        console.error('Login error:', err);
        res.status(500).json({ 
            status: "error", 
            message: "Server error" 
        });
    }
});

// 4. Get all users (except current user)
app.get('/api/users', auth, async (req, res) => {
    try {
        const users = await User.find(
            { _id: { $ne: req.user.id } },
            { username: 1, _id: 0 }  // Only username, no ID
        );
        
        res.json({ 
            status: "success", 
            users 
        });
    } catch (err) {
        res.status(500).json({ 
            status: "error", 
            message: "Failed to load users" 
        });
    }
});
// 5. Get chat history
app.get('/api/messages/:receiverId', auth, async (req, res) => {
    try {
        const { receiverId } = req.params;
        const senderId = req.user.id;

        const messages = await Message.find({
            $or: [
                { sender: senderId, receiver: receiverId },
                { sender: receiverId, receiver: senderId }
            ]
        })
        .populate('sender', 'username')
        .populate('receiver', 'username')
        .sort({ created_at: 1 })
        .limit(100);

        // Mark messages as read
        await Message.updateMany(
            { 
                sender: receiverId, 
                receiver: senderId, 
                is_read: false 
            },
            { is_read: true }
        );

        res.json({ 
            status: "success", 
            messages 
        });
    } catch (err) {
        console.error('Error fetching messages:', err);
        res.status(500).json({ 
            status: "error", 
            message: "Failed to load messages" 
        });
    }
});

// 6. Logout
app.post('/api/logout', auth, (req, res) => {
    res.clearCookie('token');
    res.json({ 
        status: "success", 
        message: "Logged out successfully" 
    });
});

// ----------------------
// Start Server
// ----------------------
const PORT = 4590;
const HOST = '10.10.15.140';

server.listen(PORT, HOST, () => {
    console.log(`Server running on http://${HOST}:${PORT}`);
});